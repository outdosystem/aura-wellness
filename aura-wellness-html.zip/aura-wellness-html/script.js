// Header scroll state
const header = document.getElementById('mainNav');
const onScroll = () => header.classList.toggle('scrolled', window.scrollY > 30);
window.addEventListener('scroll', onScroll); onScroll();

// Reveal on scroll
const io = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
}, { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach(el => io.observe(el));

// Services
const SERVICES = [
  { name:"Botox & Neuromodulators", img:"assets/service-botox.jpg",  desc:"Precision-placed neuromodulators that soften expression lines while preserving natural movement.", bens:["Smooths fine lines","Preventative aging","Natural results"] },
  { name:"Dermal Fillers",          img:"assets/service-lips.jpg",   desc:"Sculpt, restore, and refine with premium hyaluronic acid fillers for harmony and definition.", bens:["Volume restoration","Facial contouring","Long-lasting"] },
  { name:"Medical Weight Loss",     img:"assets/service-weight.jpg", desc:"Physician-led GLP-1 programs and metabolic protocols built around your goals and biology.", bens:["GLP-1 therapy","Body composition","Concierge support"] },
  { name:"IV Therapy & Wellness",   img:"assets/service-iv.jpg",     desc:"Bespoke intravenous infusions for energy, immunity, recovery, and radiant skin from within.", bens:["Hydration & energy","Glow infusions","Recovery blends"] },
  { name:"Skin Rejuvenation",       img:"assets/gallery-4.jpg",      desc:"Medical-grade facials, PRP, microneedling and chemical peels for luminous, ageless skin.", bens:["Microneedling + PRP","Chemical peels","Custom regimens"] },
  { name:"Laser Treatments",        img:"assets/service-laser.jpg",  desc:"Advanced laser platforms for skin tightening, pigmentation, redness and hair reduction.", bens:["Skin tightening","Pigment correction","Lasting clarity"] },
];
document.getElementById('serviceList').innerHTML = SERVICES.map((s,i)=>`
  <div class="svc-row reveal ${i%2?'rev':''}">
    <div class="svc-img">
      <img src="${s.img}" alt="${s.name}" loading="lazy">
      <span class="svc-tag">0${i+1} · Signature</span>
    </div>
    <div>
      <span class="eyebrow">Treatment</span>
      <h3 class="svc-name">${s.name}</h3>
      <div class="hairline mt-3"></div>
      <p class="svc-desc">${s.desc}</p>
      <ul class="svc-list">${s.bens.map(b=>`<li><span class="dot"><i class="bi bi-stars"></i></span>${b}</li>`).join('')}</ul>
      <a href="#contact" class="learn-link">Learn More <i class="bi bi-arrow-right"></i></a>
    </div>
  </div>`).join('');
document.querySelectorAll('#serviceList .reveal').forEach(el=>io.observe(el));

// Why
const WHY = [
  ["bi-award","Expert Practitioners","Board-certified physicians and master injectors with decades of combined artistry."],
  ["bi-people","Personalized Treatments","Every protocol is bespoke — designed around your anatomy, lifestyle, and goals."],
  ["bi-shield-check","FDA-Approved Procedures","Only premium, FDA-cleared products and devices ever touch your skin."],
  ["bi-eyedropper","Cutting-Edge Technology","Latest-generation laser, RF, and regenerative platforms in every treatment room."],
  ["bi-gem","Luxury Environment","A serene, private setting that feels more boutique hotel than medical office."],
  ["bi-stars","Exceptional Results","Natural, refined outcomes that age gracefully and feel unmistakably you."],
];
document.getElementById('whyGrid').innerHTML = WHY.map(([i,t,d])=>`
  <div class="col-sm-6 col-lg-4 reveal"><div class="why-card">
    <div class="why-icon"><i class="bi ${i}"></i></div>
    <h3>${t}</h3><div class="hairline mt-2"></div><p>${d}</p>
  </div></div>`).join('');
document.querySelectorAll('#whyGrid .reveal').forEach(el=>io.observe(el));

// Featured
const FEAT = [
  ["bi-droplet-half","Botox","from $12 / unit","Smooth expression lines with precision-placed neuromodulators."],
  ["bi-heart","Lip Fillers","from $650","Naturally enhanced volume, definition and symmetry."],
  ["bi-activity","Weight Loss Program","from $399 / mo","Physician-led GLP-1 and metabolic optimization."],
  ["bi-droplet","IV Therapy","from $185","Hydration, glow, immunity and recovery infusions."],
  ["bi-lightning-charge","Skin Tightening","from $850","Non-invasive RF and ultrasound for visible lift."],
  ["bi-flower1","Facial Rejuvenation","from $295","Medical-grade facials tailored to your skin goals."],
];
document.getElementById('featuredGrid').innerHTML = FEAT.map(([i,t,p,d])=>`
  <div class="col-sm-6 col-lg-4 reveal"><div class="feat-card">
    <i class="bi ${i} lead-icon"></i>
    <h3>${t}</h3><div class="hairline mt-2"></div><p>${d}</p>
    <div class="feat-foot"><span class="price">${p}</span><a href="#contact">Book →</a></div>
  </div></div>`).join('');
document.querySelectorAll('#featuredGrid .reveal').forEach(el=>io.observe(el));

// Lightbox
const lb = document.getElementById('lightbox'), lbImg = document.getElementById('lbImg');
document.querySelectorAll('.m-item').forEach(b=>b.addEventListener('click',()=>{ lbImg.src = b.dataset.img; lb.classList.add('show'); }));
lb.addEventListener('click',()=>lb.classList.remove('show'));

// Contact form
document.getElementById('contactForm').addEventListener('submit',e=>{
  e.preventDefault();
  alert("Thank you — we'll be in touch within one business day.");
  e.target.reset();
});
